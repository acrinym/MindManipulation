QUICK INTRO from Jim

I have now made things slightly easier for Windows users thanks to the
free InnoSetup installer (http://www.innosetup.com/).  After
installation you will find an examples directory on your desktop, and
you can play any of the SBaGen sequence files inside it by
double-clicking on them.  Stop a sequence by using Ctrl-C.  If you
want to edit a sequence instead of playing it, right-click and select
"Edit sequence".  If you want to write a sequence to disk as a WAV
file (out.wav), right-click and select "Write to WAV".

Every new version of SBaGen now installs in two places -- into the
Program Files directory, and also into an examples directory on the
desktop.  The examples directory is never uninstalled because it is
there for you to edit and make modifications to.  Feel free to move
these example files to other locations, or copy or rename them.

See SBAGEN.TXT for full documentation.